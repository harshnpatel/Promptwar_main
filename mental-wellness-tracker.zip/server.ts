import express from "express";
import path from "path";
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-loaded Gemini Client
let genAIClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI {
  if (!genAIClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing. Please declare it in Settings > Secrets.");
    }
    genAIClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return genAIClient;
}

// 1. Analyze Journal Entry
app.post("/api/analyze-journal", async (req, res) => {
  try {
    const { entryText, mood, academicTarget, hoursStudied } = req.body;
    if (!entryText || !entryText.trim()) {
      return res.status(400).json({ error: "Journal entry text is required." });
    }

    const ai = getGenAI();
    const prompt = `
      You are an elite, highly empathetic educational psychologist and stress management counselor specializing in competitive school and entrance exams (such as NEET, JEE, CUET, CAT, GATE, UPSC, board exams).
      
      Analyse the following student's journal of their study day:
      - Academic Focus/Exam Target: ${academicTarget || "Competitive Exams"}
      - Current Mood: ${mood || "Unknown"}
      - Hours Studied: ${hoursStudied !== undefined ? hoursStudied : "unspecified"} hours
      
      Student's Journal text:
      "${entryText}"
      
      Tasks:
      1. Determine stress level on a scale from 1 (completely relaxed) to 10 (extremely burned out / in crisis).
      2. Identify the primary emotions explicitly or implicitly stated.
      3. Discover hidden student-specific academic stress triggers (e.g. mock test scores, time pressure, fear of failing, parental high expectations, peers outperforming, physical fatigue, perfectionism).
      4. Detect negative thinking patterns (cognitive distortions), like catastrophizing, personalization, "should" statements, or black-and-white thinking.
      5. Provide warm, personalized, deeply encouraging, non-judgmental coping advice. Do not use generic advice. Address their exam context directly.
      6. Formulate a specific title for a dynamic 5-minute somatic, cognitive, or breathing exercise that matches their stress type.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a warm, supportive, empathetic advisor for exam-stressed students. You speak to them with deep care and objective psychology facts. Direct and practical.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            stressLevel: {
              type: Type.INTEGER,
              description: "Stress level from 1 (perfect peace) to 10 (extreme panic/burnout)."
            },
            primaryEmotions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Array of identified feelings/emotions."
            },
            hiddenTriggers: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Underlying triggers causing the anxiety or stress."
            },
            cognitiveDistortions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "A list of negative thinking patterns found in the message (e.g., Catastrophizing, Perfectionism, Fortune-Telling)."
            },
            personalizedAdvice: {
              type: Type.STRING,
              description: "Supportive, actionable advice specifically addressing the student's entry and target milestone."
            },
            recommendedActivity: {
              type: Type.STRING,
              description: "A title of a micro-mindfulness exercise tailored to their state (e.g., 'Box Breathing for NEET Anxiety' or '3-Step Imposter Syndrome Reframe')."
            }
          },
          required: ["stressLevel", "primaryEmotions", "hiddenTriggers", "cognitiveDistortions", "personalizedAdvice", "recommendedActivity"]
        }
      }
    });

    const analysisText = response.text;
    if (!analysisText) {
      throw new Error("No analysis response generated from the AI model.");
    }

    const parsedResult = JSON.parse(analysisText.trim());
    return res.json(parsedResult);

  } catch (error: any) {
    console.error("Error analyzing journal:", error);
    return res.status(500).json({ error: error.message || "Failed to analyze journal entry." });
  }
});

// 2. Chat with Empathetic Digital Companion
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history, journalContext } = req.body;
    if (!message) {
      return res.status(400).json({ error: "Message is required." });
    }

    const ai = getGenAI();

    // Context format
    let studentContextPrompt = "";
    if (journalContext && journalContext.length > 0) {
      studentContextPrompt = `Here is some background context on the student's recent daily logs for reference:
${journalContext.map((item: any, idx: number) => `- Entry [${item.date?.split('T')[0] || idx}]: Mood: ${item.mood}, Exam Target: ${item.academicTarget}, Main Triggers: ${item.analysis?.hiddenTriggers?.join(', ') || 'none'}, Primary issues: ${item.entryText.substring(0, 100)}...`).join("\n")}
Please use this background to make your guidance deeply personalized. Do not list this background to them explicitly.`;
    }

    // Set up chat system instruction
    const systemInstr = `
You are 'Ananya', an incredibly warm, deeply empathetic, and highly resourceful AI Mental Wellness Companion for school and competitive exam students (JEE, NEET, GATE, UPSC, UPSC-CSE, CAT, CBSE Boards).
Your purpose is to offer an always-available, compassionate space to vent, validate their feelings of pressure, self-doubt, and exhaustion, and help them dismantle toxic academic stress.

Core Directives:
1. Speak style: Conversational, gentle, compassionate, and wise. Use warm, natural language. Avoid cold clinical jargon.
2. Be brief: Keep responses concise (usually 2-4 sentences or short bullet points) so the student is not overwhelmed by text.
3. Validate first: Always start by honoring their feeling (e.g., "I hear you, and it makes complete sense that you're exhausted..."). Never dismiss or offer premature solutions.
4. Exam aware: Understand student milestones (mock exams, syllabus overwhelm, parent pressure, retention problems).
5. Gentle coping: Offer 1 tiny, actionable, practical, or somatic step (e.g., "stretch your shoulders right now", "take 3 deep breaths before reading the next question").
`;

    // Process history into correct structure for chat or just formulate inline since it works beautifully
    // We will build a complete contents arrays of previous dialogs
    const formattedContents: any[] = [];
    if (studentContextPrompt) {
      formattedContents.push({
        role: "user",
        parts: [{ text: studentContextPrompt }]
      });
      formattedContents.push({
        role: "model",
        parts: [{ text: "Understood. I will use the student's recent journal patterns to guide my empathy and advice, keeping it entirely context-aware." }]
      });
    }

    if (history && history.length > 0) {
      history.slice(-10).forEach((chat: any) => {
        formattedContents.push({
          role: chat.sender === 'user' ? 'user' : 'model',
          parts: [{ text: chat.text }]
        });
      });
    }

    formattedContents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedContents,
      config: {
        systemInstruction: systemInstr,
        temperature: 0.7,
      }
    });

    return res.json({ response: response.text });
  } catch (error: any) {
    console.error("Error in companion chat:", error);
    return res.status(500).json({ error: error.message || "Failed to process chat with companion." });
  }
});

// 3. Dynamic Custom Mindfulness Exercise
app.post("/api/generate-meditation", async (req, res) => {
  try {
    const { stressTriggers, mood, academicTarget } = req.body;
    const ai = getGenAI();

    const prompt = `
      Create a highly customized, soothing 5-minute somatic, visualization, or breathing exercise for a student.
      Student status:
      - Mood: ${mood || "Unknown"}
      - Key Triggers: ${stressTriggers ? stressTriggers.join(", ") : "general exam anxiety"}
      - Preparing for: ${academicTarget || "competitive tests"}

      Provide a JSON output detailing:
      - title: Cozy and inviting title
      - duration: "5 minutes"
      - type: choose one of "breathing" | "grounding" | "reframing" | "affirmation"
      - description: A short, gentle intro explaining how this will help their specific trigger.
      - steps: A detailed step-by-step list (4-6 steps) indicating what they should do with their breathing, physical posture, or thoughts. Make it feel highly safe and comforting.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a peaceful meditation guide and somatic therapist who writes beautifully calm, step-by-step relaxations for test preparation weariness.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            duration: { type: Type.STRING },
            type: { type: Type.STRING },
            description: { type: Type.STRING },
            steps: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["title", "duration", "type", "description", "steps"]
        }
      }
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("Failed to generate mindfulness exercise.");
    }

    return res.json(JSON.parse(resultText.trim()));
  } catch (error: any) {
    console.error("Error creating meditation:", error);
    return res.status(500).json({ error: error.message || "Failed to generate exercise." });
  }
});

// Setup Vite Dev server or production static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // Serve index.html for all client side routes
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
