export type MoodType = 'Anxious' | 'Overwhelmed' | 'Exhausted' | 'Calm' | 'Optimistic' | 'Stressed' | 'Motivated';

export interface JournalAnalysis {
  stressLevel: number; // 1-10
  primaryEmotions: string[];
  hiddenTriggers: string[];
  cognitiveDistortions: string[]; // e.g. "All-or-nothing thinking", "Catastrophizing"
  personalizedAdvice: string;
  recommendedActivity: string; // Title of a recommended coping exercise
}

export interface JournalEntry {
  id: string;
  date: string; // ISO string
  mood: MoodType;
  academicTarget: string; // e.g. "UPSC Prep", "NEET revision"
  hoursStudied: number;
  entryText: string;
  analysis?: JournalAnalysis;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string; // ISO string
}

export interface MindfulnessExercise {
  id: string;
  title: string;
  duration: string;
  type: 'breathing' | 'grounding' | 'reframing' | 'affirmation';
  steps: string[];
  description: string;
}
