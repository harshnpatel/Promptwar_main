import React, { useState, useEffect } from 'react';
import { JournalEntry } from './types';
import JournalSection from './components/JournalSection';
import CompanionSection from './components/CompanionSection';
import MindfulnessSection from './components/MindfulnessSection';
import AnalyticsSection from './components/AnalyticsSection';
import { BookOpen, MessageSquare, Wind, BarChart3, Shield, Heart, GraduationCap, Clock } from 'lucide-react';

const SEED_ENTRIES: JournalEntry[] = [
  {
    id: 'seed-1',
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
    mood: 'Overwhelmed',
    academicTarget: 'JEE Prep',
    hoursStudied: 10,
    entryText: "Spent ten hours solving calculus and physics mock series. I am so tired. The equations are blurring together. Parents keep calling to ask if I will make the cutoff rank. I feel very dry inside and scared of letting them down.",
    analysis: {
      stressLevel: 8,
      primaryEmotions: ["Mental Exhaustion", "Underlying Dread", "Fear of Failure"],
      hiddenTriggers: ["Parental High Expectations", "Syllabus Overwhelm", "Mock Exam Speed"],
      cognitiveDistortions: ["Catastrophizing", "Should Statements"],
      personalizedAdvice: "Ten hours of rigorous math is a massive cognitive load. Your brain is asking for a silent offline boundary. Your effort itself is the victory, and your mock scores are information parameters, not measures of your personal worth.",
      recommendedActivity: "Imposter Syndrome Rational Decelerator"
    }
  },
  {
    id: 'seed-2',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
    mood: 'Exhausted',
    academicTarget: 'JEE Prep',
    hoursStudied: 8.5,
    entryText: "Did midnight organic chemistry revisions. Memorized structures but kept forgetting fundamental reaction paths. Started crying because peer groups are posting mock results and physical tiredness is hitting hard.",
    analysis: {
      stressLevel: 7,
      primaryEmotions: ["Helplessness", "Social Isolation"],
      hiddenTriggers: ["Peer Social Comparison", "Sleep Deprivation"],
      cognitiveDistortions: ["All-or-Nothing Thinking", "Compare-and-Despair Trap"],
      personalizedAdvice: "Studying hard-mechanisms past midnight causes cognitive friction and memory retention decay. Prioritize high-quality sleep to cement retention. Stop looking at peer scores; your path is solely your own.",
      recommendedActivity: "Chair Somatic Neck & Shoulder Release"
    }
  },
  {
    id: 'seed-3',
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // Yesterday
    mood: 'Calm',
    academicTarget: 'JEE Prep',
    hoursStudied: 5.5,
    entryText: "Took advice to slow down. Spent 5.5 hours analyzing my mock errors instead of rushed reading. Walked in the local park in the evening and tried standard breathing. Feel slightly lighter and slept okay.",
    analysis: {
      stressLevel: 4,
      primaryEmotions: ["Pacing", "Coping Acceptance"],
      hiddenTriggers: ["Mock Error Analysis", "Cortisol Sabbatical"],
      cognitiveDistortions: [],
      personalizedAdvice: "Incredible shift today. Walking in green spaces helps trigger standard parasympathetic relief. Studying 5.5 focused hours with sharp mental quality is infinitely more potent than 10 hours of fuzzy, panic-fueled skimming.",
      recommendedActivity: "Navy SEAL Box Breathing"
    }
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'reflections' | 'companion' | 'breathing' | 'analytics'>('reflections');
  const [entries, setEntries] = useState<JournalEntry[]>([]);

  // Load from local storage or set seed entries
  useEffect(() => {
    const saved = localStorage.getItem('STUDENT_WELLNESS_LOGS_A1');
    if (saved) {
      try {
        setEntries(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse saved welfare logs, falling back to seeds.", e);
        setEntries(SEED_ENTRIES);
      }
    } else {
      setEntries(SEED_ENTRIES);
    }
  }, []);

  const addEntry = async (newEntry: JournalEntry) => {
    const updated = [newEntry, ...entries];
    setEntries(updated);
    localStorage.setItem('STUDENT_WELLNESS_LOGS_A1', JSON.stringify(updated));
  };

  // Stress level text warning
  const getTopLevelStressSummary = () => {
    if (entries.length === 0) return { title: "Dormant", color: "text-stone-500", bg: "bg-stone-100" };
    const latest = entries[0];
    const stress = latest.analysis?.stressLevel || 5;
    if (stress >= 8) {
      return { title: `Peak Study Load [${stress}/10]`, color: "text-rose-600 font-bold", bg: "bg-rose-50 border border-rose-200" };
    }
    if (stress >= 5) {
      return { title: `Moderate Stress [${stress}/10]`, color: "text-amber-600 font-bold", bg: "bg-amber-50 border border-amber-200" };
    }
    return { title: `Balanced [${stress}/10]`, color: "text-emerald-600 font-bold", bg: "bg-emerald-50 border border-emerald-200" };
  };

  const stressSummary = getTopLevelStressSummary();

  return (
    <div className="min-h-screen bg-stone-50 text-stone-800 font-sans flex flex-col" id="master-wellbeing-app">
      {/* Header Anchor */}
      <header className="bg-white border-b border-stone-200/60 sticky top-0 z-40" id="global-header-bar">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-stone-900 text-amber-305 flex items-center justify-center text-stone-100 shadow-sm border border-stone-820 font-bold font-serif">
                S
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-bold text-stone-900 tracking-tight">Sushila Student Sanity Sanctuary</h1>
                  <span className="text-[10px] bg-amber-450/10 text-amber-700 px-2 py-0.5 rounded-full border border-amber-200 font-medium">NEET, JEE, UPSC Aid</span>
                </div>
                <p className="text-xs text-stone-500 font-medium">Empathetic AI counseling diagnostic for competitive milestones.</p>
              </div>
            </div>

            {/* Quick telemetry badges */}
            <div className="flex flex-wrap items-center gap-3">
              <div className={`px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 ${stressSummary.bg}`}>
                <Shield className="w-3.5 h-3.5 stroke-[2.5]" />
                <span className={stressSummary.color}>{stressSummary.title}</span>
              </div>
              <div className="bg-white border border-stone-200 px-3 py-1.5 rounded-xl text-xs text-stone-605 flex items-center gap-1.5 font-medium">
                <Clock className="w-3.5 h-3.5 text-stone-400" />
                <span>Study Load average: <strong className="text-stone-800 font-mono">{(entries.reduce((a,c)=>a+c.hoursStudied, 0)/(entries.length||1)).toFixed(1)}h</strong></span>
              </div>
              <div className="bg-stone-900 text-amber-50 px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 font-serif border border-stone-800">
                <Heart className="w-3.5 h-3.5 fill-amber-300 stroke-none" />
                <span>Sanity Anchor active</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8" id="primary-app-layout">
        {/* Navigation Tabs Bar */}
        <div className="bg-white p-1.5 rounded-2xl border border-stone-100 shadow-xs flex flex-wrap gap-1 max-w-4xl" id="nav-tabs">
          <button
            onClick={() => setActiveTab('reflections')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'reflections'
                ? 'bg-stone-900 text-amber-50 shadow-sm'
                : 'text-stone-600 hover:bg-stone-50 hover:text-stone-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            1. Mirror of Reflections
          </button>

          <button
            onClick={() => setActiveTab('companion')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'companion'
                ? 'bg-stone-900 text-amber-50 shadow-sm'
                : 'text-stone-600 hover:bg-stone-50 hover:text-stone-800'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            2. Talk with Ananya (AI Chat)
          </button>

          <button
            onClick={() => setActiveTab('breathing')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'breathing'
                ? 'bg-stone-900 text-amber-50 shadow-sm'
                : 'text-stone-600 hover:bg-stone-50 hover:text-stone-800'
            }`}
          >
            <Wind className="w-4 h-4" />
            3. Breath & Somatics
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'analytics'
                ? 'bg-stone-900 text-amber-50 shadow-sm'
                : 'text-stone-600 hover:bg-stone-50 hover:text-stone-800'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            4. Stress Analytics
          </button>
        </div>

        {/* Informative introduction greeting context card */}
        <div className="bg-linear-to-r from-stone-900 to-stone-800 text-stone-100 rounded-2xl p-6 border border-stone-800 flex items-center justify-between gap-6 flex-wrap shadow-md">
          <div className="space-y-1.5 max-w-[580px]">
            <span className="text-[10px] bg-amber-400 text-stone-900 font-bold px-2 py-0.5 rounded-md uppercase tracking-wider">Board & Entrance Prep Aid</span>
            <h2 className="font-bold text-lg text-stone-50 font-serif">Your Stress-Proof Exam Companion</h2>
            <p className="text-xs text-stone-300 leading-relaxed font-normal">
              High-stakes tests are mental marathons. Standard apps just count hours, but Sushila analyzes your unfiltered thoughts to excavate cognitive traps, calculate exact emotional pressure levels, and give you custom restorative somatics.
            </p>
          </div>
          <div className="flex items-center gap-2 border border-stone-700 bg-stone-950/40 p-3.5 rounded-xl">
            <GraduationCap className="w-8 h-8 text-amber-400" />
            <div className="text-left">
              <span className="text-[9px] text-stone-500 font-bold block uppercase tracking-widest leading-none mb-1">Coping Philosophy</span>
              <span className="text-xs font-bold text-stone-200">Balanced Minds Solve Best</span>
            </div>
          </div>
        </div>

        {/* Render Active Tab */}
        <div className="transition-all duration-300">
          {activeTab === 'reflections' && (
            <JournalSection entries={entries} onAddEntry={addEntry} />
          )}

          {activeTab === 'companion' && (
            <CompanionSection journalEntries={entries} />
          )}

          {activeTab === 'breathing' && (
            <MindfulnessSection recentJournal={entries[0] || null} />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsSection entries={entries} />
          )}
        </div>
      </main>

      {/* Peace Footer */}
      <footer className="bg-white border-t border-stone-105 py-6 mt-12 text-center text-xs text-stone-400" id="global-footer">
        <div className="max-w-7xl mx-auto px-4">
          <p>© 2026 Sushila Student Sanity Sanctuary. Your journaling data stays private in your browser local secure cache.</p>
          <div className="flex items-center justify-center gap-1.5 mt-2">
            <span>Always prepared with Care</span>
            <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
            <span>by Counseling AI</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
