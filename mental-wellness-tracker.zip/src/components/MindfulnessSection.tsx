import React, { useState, useEffect, useRef } from 'react';
import { MindfulnessExercise, JournalEntry } from '../types';
import { Wind, Play, Square, Sparkles, Smile, RefreshCw, AlertCircle, ArrowRight, Heart } from 'lucide-react';

interface MindfulnessSectionProps {
  recentJournal: JournalEntry | null;
}

// Predefined exercises
const STATIC_EXERCISES: MindfulnessExercise[] = [
  {
    id: 'box-breathing',
    title: 'Navy SEAL Box Breathing',
    duration: '4 minutes',
    type: 'breathing',
    description: 'The standard protocol used by elite operators to silence physical stress responses and restore sharp academic concentration.',
    steps: [
      'Inhale slowly and deeply through your nose for 4 complete seconds.',
      'Hold the air in your lungs for 4 silent, relaxed seconds.',
      'Exhale calmly through your mouth for 4 slow seconds, fully emptying your lungs.',
      'Hold your lungs empty for 4 steady seconds before the next breath.'
    ]
  },
  {
    id: 'somatic-neck-release',
    title: 'Chair Somatic Neck & Shoulder Release',
    duration: '3 minutes',
    type: 'grounding',
    description: 'Designed for students hunched over books or monitors for 10+ hours. Immediately releases mechanical physical tension.',
    steps: [
      'Sit tall. Roll your shoulders up towards your ears, then slowly roll them backwards and completely down.',
      'Gently drop your chin towards your chest, holding for 3 deep breaths while feeling the neck unfold.',
      'Tilt your left ear towards your left shoulder. Gently extend your right arm down toward the floor to double the physical release.',
      'Repeat on the opposite side. Draw 3 deep, slow bellied breaths in each pose.'
    ]
  },
  {
    id: 'cat-reframe',
    title: 'Imposter Syndrome Rational Decelerator',
    duration: '5 minutes',
    type: 'reframing',
    description: 'Calmly dismantles thoughts like "I am not smart enough to clear NEET/JEE/UPSC," replacing them with realistic confidence.',
    steps: [
      'Close your eyes. Identify the critical inner voice telling you that you are guaranteed to fail.',
      'Note that this fear is an emotional signal, not a forecast of the future. Fear cannot alter facts.',
      'Write down (or whisper) 3 real pieces of evidence of your hard work or past problem-solving success.',
      'Affirm to yourself: My worth is not defined by a single exam digit. I am preparing; that is enough.'
    ]
  }
];

export default function MindfulnessSection({ recentJournal }: MindfulnessSectionProps) {
  const [exercises, setExercises] = useState<MindfulnessExercise[]>(STATIC_EXERCISES);
  const [activeExercise, setActiveExercise] = useState<MindfulnessExercise>(STATIC_EXERCISES[0]);
  const [loadingCustom, setLoadingCustom] = useState(false);
  const [customError, setCustomError] = useState("");

  // Breathing simulation state
  const [breathingActive, setBreathingActive] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold (Full)' | 'Exhale' | 'Hold (Empty)'>('Inhale');
  const [secondsRemaining, setSecondsRemaining] = useState(4);
  const [cycleCount, setCycleCount] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Quick helper to generate customized mindfulness exercise based on student state
  const generateCustomExercise = async () => {
    setLoadingCustom(true);
    setCustomError("");

    const mood = recentJournal?.mood || "Stressed";
    const triggers = recentJournal?.analysis?.hiddenTriggers || ["test day pressure", "syllabus overflow"];
    const target = recentJournal?.academicTarget || "high-stakes exams";

    try {
      const response = await fetch('/api/generate-meditation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mood,
          stressTriggers: triggers,
          academicTarget: target
        })
      });

      if (!response.ok) {
        throw new Error("Failed to generate custom mindfulness session from API.");
      }

      const rawEx = await response.json();
      
      const newEx: MindfulnessExercise = {
        id: crypto.randomUUID(),
        title: rawEx.title || "Custom Student Serenity Prompt",
        duration: rawEx.duration || "5 minutes",
        type: rawEx.type || "breathing",
        description: rawEx.description || "Synthesised from your recent stressed journal markers.",
        steps: rawEx.steps || ["Focus", "Breathe", "Relax"]
      };

      setExercises((prev) => [newEx, ...prev.filter(e => e.id !== newEx.id)]);
      setActiveExercise(newEx);
    } catch (err: any) {
      console.error(err);
      setCustomError("Unable to synthesize custom exercise. Make sure your Gemini connection is established.");
    } finally {
      setLoadingCustom(false);
    }
  };

  // Breathing loop effects
  useEffect(() => {
    if (breathingActive) {
      timerRef.current = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            // transition to next phase
            setBreathPhase((currentPhase) => {
              switch (currentPhase) {
                case 'Inhale':
                  return 'Hold (Full)';
                case 'Hold (Full)':
                  return 'Exhale';
                case 'Exhale':
                  return 'Hold (Empty)';
                case 'Hold (Empty)':
                  setCycleCount((c) => c + 1);
                  return 'Inhale';
                default:
                  return 'Inhale';
              }
            });
            return 4; // Reset to 4 seconds for box breathing blocks
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      setSecondsRemaining(4);
      setBreathPhase('Inhale');
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [breathingActive]);

  const toggleBreathing = () => {
    if (breathingActive) {
      setBreathingActive(false);
      setCycleCount(0);
    } else {
      setBreathingActive(true);
    }
  };

  const getSomaticProgressColor = () => {
    switch (breathPhase) {
      case 'Inhale': return 'bg-amber-400';
      case 'Hold (Full)': return 'bg-orange-400';
      case 'Exhale': return 'bg-teal-400';
      case 'Hold (Empty)': return 'bg-slate-400';
    }
  };

  const getSomaticInstruction = () => {
    switch (breathPhase) {
      case 'Inhale': return 'Expand your abdomen. Let the energy fill you.';
      case 'Hold (Full)': return 'Be completely still. Experience the peaceful focus.';
      case 'Exhale': return 'Release all tension. Let expectations drift away.';
      case 'Hold (Empty)': return 'Rest in the absolute quiet quietness before rising.';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="mindfulness-section-root">
      {/* Exercise Catalogue & Dynamic generator */}
      <div className="lg:col-span-7 space-y-6">
        {/* Customized button block */}
        <div className="bg-stone-900 text-stone-100 rounded-2xl p-5 border border-stone-850 flex items-center justify-between gap-4 flex-wrap">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-amber-400 text-xs font-semibold mb-1">
              <Sparkles className="w-3.5 h-3.5" /> AI Somatic Synth
            </div>
            <h3 className="font-semibold text-sm text-stone-100">Need immediate, micro-targeted relief?</h3>
            <p className="text-xs text-stone-400 mt-0.5 leading-relaxed">
              We'll parse your study hours ({recentJournal?.hoursStudied || 'N/A'} hrs today) and recent mood ({recentJournal?.mood || 'Stressed'}) to generate a tailored exercise.
            </p>
          </div>
          <button
            onClick={generateCustomExercise}
            disabled={loadingCustom}
            className="px-4 py-2.5 bg-amber-400 hover:bg-amber-500 disabled:bg-stone-700 text-stone-900 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            {loadingCustom ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-stone-900 border-t-white rounded-full animate-spin"></div>
                Tuning focus coordinates...
              </>
            ) : (
              <>
                Synthesize My Serenity
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>

        {customError && (
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 text-xs text-rose-600 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{customError}</span>
          </div>
        )}

        {/* Exercises selection grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {exercises.map((ex) => {
            const isActive = activeExercise.id === ex.id;
            return (
              <button
                key={ex.id}
                onClick={() => {
                  setActiveExercise(ex);
                  setBreathingActive(false);
                }}
                className={`text-left p-4 rounded-xl border transition-all flex flex-col justify-between h-[160px] ${
                  isActive 
                    ? 'bg-stone-900 border-stone-900 text-stone-100 shadow-xs' 
                    : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className={`text-[9px] px-2 py-0.5 font-bold uppercase tracking-wider rounded-sm ${
                      isActive ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20' : 'bg-stone-100 text-stone-600 border border-stone-200/50'
                    }`}>
                      {ex.type}
                    </span>
                    <span className={`text-[10px] font-mono ${isActive ? 'text-stone-400' : 'text-stone-400'}`}>{ex.duration}</span>
                  </div>
                  <h4 className="font-semibold text-xs line-clamp-2 leading-tight">{ex.title}</h4>
                </div>
                <p className={`text-[10px] line-clamp-3 leading-relaxed mt-2 ${isActive ? 'text-stone-300' : 'text-stone-500'}`}>
                  {ex.description}
                </p>
              </button>
            );
          })}
        </div>

        {/* Selected exercise execution card */}
        <div className="bg-white rounded-2xl p-6 border border-stone-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div>
              <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">Active Exercise Sequence</span>
              <h3 className="font-semibold text-stone-850 text-base">{activeExercise.title}</h3>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-stone-400 block">Class</span>
              <span className="text-xs font-semibold text-stone-800 capitalize bg-stone-100 px-2.5 py-0.5 rounded-full">{activeExercise.type}</span>
            </div>
          </div>

          <div className="space-y-3.5">
            {activeExercise.steps.map((step, idx) => (
              <div key={idx} className="flex gap-4 items-start text-stone-700">
                <span className="w-6 h-6 rounded-full bg-stone-900 text-amber-200 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 font-mono">
                  {idx + 1}
                </span>
                <p className="text-xs leading-relaxed font-sans">{step}</p>
              </div>
            ))}
          </div>

          {activeExercise.type === 'breathing' && (
            <div className="pt-4 border-t border-stone-100 flex justify-end">
              <button
                onClick={toggleBreathing}
                className="flex items-center gap-1.5 px-4.5 py-2.5 bg-stone-905 hover:bg-stone-800 text-amber-55 rounded-xl text-xs font-bold transition-all shadow-xs shrink-0 cursor-pointer"
              >
                {breathingActive ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                {breathingActive ? 'Stop Active Breathing' : 'Initialize Breathing Guides'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Visual respiration feedback engine */}
      <div className="lg:col-span-5">
        <div className="bg-stone-50 rounded-2xl p-6 border border-stone-200/60 h-full flex flex-col justify-between space-y-6">
          <div className="text-center">
            <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block mb-1">Visual somatic pacing device</span>
            <h3 className="font-semibold text-sm text-stone-800 mb-1">Respiration Pacing Simulator</h3>
            <p className="text-xs text-stone-550 max-w-[280px] mx-auto leading-relaxed">
              Used to suppress exam flight-or-fight signals instantly. Match your breath to the expanding bubble.
            </p>
          </div>

          {/* Interactive Bubble */}
          <div className="flex flex-col items-center justify-center py-6 select-none relative">
            <div className="relative w-56 h-56 flex items-center justify-center">
              {/* Outer Glow Ring */}
              <div className={`absolute inset-0 rounded-full border-2 border-dashed border-stone-300 transition-all duration-1000 ${
                breathingActive ? 'animate-spin' : ''
              }`} style={{ animationDuration: '40s' }}></div>

              {/* Dynamic Scaling Circle */}
              <div 
                className={`rounded-full flex items-center justify-center transition-all duration-1000 transform border shadow-2xs ${getSomaticProgressColor()} ${
                  !breathingActive 
                    ? 'w-36 h-36 bg-stone-200 border-stone-300 text-stone-600 shadow-none' 
                    : breathPhase === 'Inhale' 
                      ? 'w-48 h-48 scale-102 ring-8 ring-amber-400/20 text-amber-950 border-amber-500' 
                      : breathPhase === 'Hold (Full)' 
                        ? 'w-48 h-48 scale-100 ring-4 ring-orange-400/30 text-orange-950 border-orange-500 font-bold' 
                        : breathPhase === 'Exhale' 
                          ? 'w-24 h-24 scale-95 ring-8 ring-teal-400/20 text-teal-950 border-teal-500' 
                          : 'w-24 h-24 scale-95 ring-4 ring-slate-400/10 text-slate-950 border-slate-500 font-bold'
                }`}
              >
                <div className="text-center font-mono">
                  {breathingActive ? (
                    <>
                      <div className="text-[10px] uppercase font-bold tracking-widest leading-none mb-1 opacity-75">
                        {breathPhase}
                      </div>
                      <div className="text-3xl font-extrabold tracking-tight">
                        {secondsRemaining}s
                      </div>
                    </>
                  ) : (
                    <>
                      <Wind className="w-8 h-8 text-stone-400 mx-auto mb-1.5 animate-pulse" />
                      <span className="text-[10px] font-semibold text-stone-500">Device Dormant</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Subtext info */}
            <div className="text-center mt-4">
              {breathingActive ? (
                <p className="text-xs font-medium text-stone-800 transition-all">
                  {getSomaticInstruction()}
                </p>
              ) : (
                <p className="text-xs text-stone-500 italic">
                  Select a "Breathing" class exercise and click "Initialize Breathing Guides" to wake the device.
                </p>
              )}
            </div>
          </div>

          {/* Stats bar */}
          <div className="bg-white rounded-xl p-4 border border-stone-100 flex items-center justify-around divide-x divide-stone-100 text-center">
            <div>
              <span className="text-[9px] uppercase font-bold tracking-wider text-stone-400 block mb-0.5">Frequency Target</span>
              <span className="text-xs font-semibold text-stone-700">4-4-4-4 Pace</span>
            </div>
            <div className="pl-4">
              <span className="text-[9px] uppercase font-bold tracking-wider text-stone-400 block mb-0.5">Completed cycles</span>
              <span className="text-xs font-semibold text-stone-700 font-mono">{cycleCount} loops</span>
            </div>
            <div className="pl-4">
              <span className="text-[9px] uppercase font-bold tracking-wider text-stone-400 block mb-0.5">Coping Status</span>
              <span className="text-xs font-semibold text-emerald-600 flex items-center justify-center gap-1">
                <Heart className="w-3 h-3 fill-emerald-600" /> Grounded
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
