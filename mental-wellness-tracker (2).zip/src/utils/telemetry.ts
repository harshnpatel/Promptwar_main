import { JournalEntry, MoodType } from '../types';

/**
 * Computes the average stress level across all journal entries.
 * Returns a string formatted to 1 decimal place.
 */
export function computeAverageStress(entries: JournalEntry[]): string {
  if (entries.length === 0) return "0.0";
  const total = entries.reduce((acc, curr) => acc + (curr.analysis?.stressLevel ?? 5), 0);
  return (total / entries.length).toFixed(1);
}

/**
 * Computes the average study hours logged across all journal entries.
 * Returns a string formatted to 1 decimal place.
 */
export function computeAverageHours(entries: JournalEntry[]): string {
  if (entries.length === 0) return "0.0";
  const total = entries.reduce((acc, curr) => acc + curr.hoursStudied, 0);
  return (total / entries.length).toFixed(1);
}

/**
 * Breakdown of user moods showing counts and percentage representation.
 */
export interface MoodBreakdown {
  mood: MoodType;
  count: number;
  percentage: number;
}

export function getMoodBreakdown(entries: JournalEntry[]): MoodBreakdown[] {
  if (entries.length === 0) return [];
  
  const moodCounts = entries.reduce((acc, curr) => {
    acc[curr.mood] = (acc[curr.mood] || 0) + 1;
    return acc;
  }, {} as Record<MoodType, number>);

  return Object.entries(moodCounts).map(([mood, count]) => ({
    mood: mood as MoodType,
    count: count as number,
    percentage: Math.round(((count as number) / entries.length) * 100),
  }));
}

/**
 * Extracts and sorts the most common cognitive distortions.
 */
export function getPopularDistortions(entries: JournalEntry[], limit = 4): [string, number][] {
  const allDistortions = entries.flatMap((e) => e.analysis?.cognitiveDistortions || []);
  const counts = allDistortions.reduce((acc, curr) => {
    acc[curr] = (acc[curr] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit);
}

/**
 * Extracts and sorts the most recurrent stress triggers.
 */
export function getPopularTriggers(entries: JournalEntry[], limit = 5): [string, number][] {
  const allTriggers = entries.flatMap((e) => e.analysis?.hiddenTriggers || []);
  const counts = allTriggers.reduce((acc, curr) => {
    acc[curr] = (acc[curr] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit);
}

/**
 * Returns a stylized representation tag of the current stress index.
 */
export interface StressSummary {
  title: string;
  color: string;
  bg: string;
}

export function getTopLevelStressSummary(entries: JournalEntry[]): StressSummary {
  if (entries.length === 0) {
    return { title: "Dormant", color: "text-stone-500", bg: "bg-stone-100" };
  }
  const latest = entries[0];
  const stress = latest.analysis?.stressLevel ?? 5;
  if (stress >= 8) {
    return {
      title: `Peak Study Load [${stress}/10]`,
      color: "text-rose-600 font-semibold",
      bg: "bg-rose-50 border border-rose-200/60",
    };
  }
  if (stress >= 5) {
    return {
      title: `Moderate Stress [${stress}/10]`,
      color: "text-amber-700 font-semibold",
      bg: "bg-amber-50 border border-amber-200/60",
    };
  }
  return {
    title: `Balanced [${stress}/10]`,
    color: "text-emerald-700 font-semibold",
    bg: "bg-emerald-50 border border-emerald-250",
  };
}
