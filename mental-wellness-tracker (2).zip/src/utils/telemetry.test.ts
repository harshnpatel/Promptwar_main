import { describe, it, expect } from 'vitest';
import { JournalEntry, JournalAnalysis } from '../types';
import {
  computeAverageStress,
  computeAverageHours,
  getMoodBreakdown,
  getPopularDistortions,
  getPopularTriggers,
  getTopLevelStressSummary,
} from './telemetry';

const mockAnalysis1: JournalAnalysis = {
  stressLevel: 8,
  primaryEmotions: ['Exhausted', 'Anxious'],
  hiddenTriggers: ['Syllabus Load', 'Mock Exam Speed'],
  cognitiveDistortions: ['Catastrophizing', 'Should Statements'],
  personalizedAdvice: 'Take a break today.',
  recommendedActivity: 'Somatic Release',
};

const mockAnalysis2: JournalAnalysis = {
  stressLevel: 4,
  primaryEmotions: ['Calm'],
  hiddenTriggers: ['Sleep Quality'],
  cognitiveDistortions: [],
  personalizedAdvice: 'Keep it up!',
  recommendedActivity: 'Navy SEAL Box Breathing',
};

const sampleEntries: JournalEntry[] = [
  {
    id: '1',
    date: '2026-06-10T00:00:00.000Z',
    mood: 'Overwhelmed',
    academicTarget: 'JEE Prep',
    hoursStudied: 10,
    entryText: 'Had a long study session.',
    analysis: mockAnalysis1,
  },
  {
    id: '2',
    date: '2026-06-11T00:00:00.000Z',
    mood: 'Calm',
    academicTarget: 'JEE Prep',
    hoursStudied: 6,
    entryText: 'Felt much more relaxed today.',
    analysis: mockAnalysis2,
  },
];

describe('Telemetry Metric Analytics', () => {
  it('correctly computes average stress with multiple logs', () => {
    const avgStress = computeAverageStress(sampleEntries);
    expect(avgStress).toBe('6.0'); // (8 + 4) / 2
  });

  it('handles empty logs list for stress level calculation', () => {
    const avgStress = computeAverageStress([]);
    expect(avgStress).toBe('0.0');
  });

  it('correctly computes average study hours', () => {
    const avgHours = computeAverageHours(sampleEntries);
    expect(avgHours).toBe('8.0'); // (10 + 6) / 2
  });

  it('handles empty logs for hours calculation', () => {
    const avgHours = computeAverageHours([]);
    expect(avgHours).toBe('0.0');
  });

  it('produces accurate mood breakdown frequencies', () => {
    const breakdown = getMoodBreakdown(sampleEntries);
    expect(breakdown).toHaveLength(2);
    
    const calmBreakdown = breakdown.find(b => b.mood === 'Calm');
    expect(calmBreakdown).toBeDefined();
    expect(calmBreakdown?.count).toBe(1);
    expect(calmBreakdown?.percentage).toBe(50);
  });

  it('extracts top cognitive distortions accurately', () => {
    const distortions = getPopularDistortions(sampleEntries);
    expect(distortions).toHaveLength(2);
    expect(distortions[0][0]).toBe('Catastrophizing');
    expect(distortions[0][1]).toBe(1);
  });

  it('extracts popular stressors and triggers', () => {
    const triggers = getPopularTriggers(sampleEntries);
    expect(triggers.map(t => t[0])).toContain('Syllabus Load');
    expect(triggers.map(t => t[0])).toContain('Sleep Quality');
  });

  it('structures correct top-level stress report tags', () => {
    const summaryHigh = getTopLevelStressSummary([sampleEntries[0]]);
    expect(summaryHigh.title).toContain('Peak Study Load');
    expect(summaryHigh.color).toContain('text-rose');

    const summaryLow = getTopLevelStressSummary([sampleEntries[1]]);
    expect(summaryLow.title).toContain('Balanced');
    expect(summaryLow.color).toContain('text-emerald');

    const summaryEmpty = getTopLevelStressSummary([]);
    expect(summaryEmpty.title).toBe('Dormant');
  });
});
