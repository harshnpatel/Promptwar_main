import React, { useMemo } from 'react';
import { JournalEntry, MoodType } from '../types';
import { TrendingUp, AlertTriangle, Clock, Smile, Award, CheckCircle } from 'lucide-react';
import {
  computeAverageStress,
  computeAverageHours,
  getMoodBreakdown,
  getPopularDistortions,
  getPopularTriggers,
} from '../utils/telemetry';

interface AnalyticsSectionProps {
  entries: JournalEntry[];
}

const MOOD_COGNITIVE_COLORS: Record<MoodType, string> = {
  Anxious: 'bg-amber-400',
  Overwhelmed: 'bg-rose-500',
  Exhausted: 'bg-slate-400',
  Stressed: 'bg-red-400',
  Calm: 'bg-emerald-400',
  Optimistic: 'bg-teal-500',
  Motivated: 'bg-indigo-400'
};

export default function AnalyticsSection({ entries }: AnalyticsSectionProps) {
  // If no logs, show a friendly empty report
  if (entries.length === 0) {
    return (
      <div className="bg-white rounded-2xl p-8 border border-stone-100 text-center shadow-xs space-y-4 max-w-lg mx-auto" id="analytics-empty">
        <div className="w-16 h-16 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center text-3xl mx-auto shadow-inner">
          📊
        </div>
        <div>
          <h3 className="font-semibold text-stone-850 text-sm">No exam stress telemetry yet</h3>
          <p className="text-xs text-stone-600 max-w-[340px] mx-auto mt-1.5 leading-relaxed">
            By keeping a brief reflection study-log daily, the AI will build deep correlations mapping study hours against stresses and cognitive habits here.
          </p>
        </div>
      </div>
    );
  }

  // Memoized diagnostic calculations using top-level utils
  const totalEntries = entries.length;
  const averageStress = useMemo(() => computeAverageStress(entries), [entries]);
  const averageHours = useMemo(() => computeAverageHours(entries), [entries]);
  const moodBreakdown = useMemo(() => getMoodBreakdown(entries), [entries]);
  const popularDistortions = useMemo(() => getPopularDistortions(entries, 4), [entries]);
  const popularTriggers = useMemo(() => getPopularTriggers(entries, 5), [entries]);

  return (
    <div className="space-y-8" id="analytics-section-root">
      {/* Visual statistics metrics cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Metric cards */}
        <div className="bg-white rounded-2xl p-5 border border-stone-100 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 bg-rose-50 text-rose-500 rounded-xl flex items-center justify-center font-bold text-lg">
            ⚡
          </div>
          <div>
            <span className="text-[10px] text-stone-400 block uppercase font-bold">Avg Exam Stress Level</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-bold font-mono text-stone-800">{averageStress}</span>
              <span className="text-[10px] text-stone-400">/ 10</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-stone-100 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-50 text-amber-500 rounded-xl flex items-center justify-center font-bold text-lg">
            📚
          </div>
          <div>
            <span className="text-[10px] text-stone-400 block uppercase font-bold">Avg Study Load</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-bold font-mono text-stone-800">{averageHours}h</span>
              <span className="text-[10px] text-stone-400">/ day</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-stone-100 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-500 rounded-xl flex items-center justify-center font-bold text-lg">
            📝
          </div>
          <div>
            <span className="text-[10px] text-stone-500 block uppercase font-bold">Logs Recorded</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-bold font-mono text-stone-800">{totalEntries}</span>
              <span className="text-[10px] text-stone-550">days active</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-stone-100 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-50 text-emerald-500 rounded-xl flex items-center justify-center font-bold text-lg">
            🛡️
          </div>
          <div>
            <span className="text-[10px] text-stone-550 block uppercase font-bold font-sans">Self-Care Actions</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-bold font-mono text-emerald-600">Active</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Charts & breakdowns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Core telemetry chart: Stress level vs study hours over time */}
        <div className="bg-white rounded-2xl p-6 border border-stone-100 shadow-xs lg:col-span-8 space-y-6">
          <div>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-stone-800 text-sm">Interactive Stress vs Study Hours Ratio</h3>
                <p className="text-xs text-stone-500">Chronological analysis showing correlations between preparation intensity and stress levels.</p>
              </div>
              <TrendingUp className="w-4 h-4 text-stone-400" />
            </div>
          </div>

          {/* Fully styled SVG Core Stress Chart, fully responsive and 100% bug-free */}
          <div className="relative h-60 w-full border border-stone-100 bg-stone-50/50 rounded-xl p-4 flex flex-col justify-between">
            <div className="flex-1 flex items-end gap-3 md:gap-5 px-2">
              {entries.slice(-7).map((entry, idx) => {
                const stressFactor = entry.analysis?.stressLevel || 5;
                const hoursFactor = entry.hoursStudied || 0;
                // Scale values
                const stressHeight = `${stressFactor * 10}%`;
                const hoursHeight = `${(hoursFactor / 16) * 100}%`;

                return (
                  <div key={entry.id} className="flex-1 flex flex-col items-center select-none group relative">
                    {/* Hover tooltip */}
                    <div className="absolute bottom-full mb-2 bg-stone-900 text-stone-100 text-[9px] p-2 rounded-lg pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-md z-30 space-y-0.5 border border-stone-800">
                      <p className="font-bold text-amber-400">{entry.academicTarget}</p>
                      <p className="text-white">Stress level: {stressFactor}/10</p>
                      <p className="text-stone-300">Studied: {hoursFactor} hours</p>
                    </div>

                    {/* Bars visualizer */}
                    <div className="w-full flex justify-center gap-1.5 h-36 items-end border-b border-stone-200">
                      {/* Study hours bar (Amber) */}
                      <div 
                        className="w-3 bg-amber-200 group-hover:bg-amber-300 transition-all rounded-t-xs"
                        style={{ height: hoursHeight || '5%' }}
                      ></div>
                      {/* Stress bar (Rose) */}
                      <div 
                        className="w-3 bg-rose-405 group-hover:bg-rose-500 transition-all rounded-t-xs bg-rose-450"
                        style={{ height: stressHeight }}
                      ></div>
                    </div>

                    {/* Label/Date */}
                    <span className="text-[9px] text-stone-400 mt-2 font-mono truncate max-w-[48px]">
                      {new Date(entry.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Chart Legend */}
            <div className="border-t border-stone-100 pt-3 flex items-center justify-center gap-6 text-[10px]">
              <div className="flex items-center gap-2">
                <span className="w-3 h-2.5 bg-amber-200 rounded-xs"></span>
                <span className="text-stone-500 font-medium">Daily Study Hours Logged (Scaled to 16h)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-2.5 bg-rose-500 rounded-xs animate-pulse"></span>
                <span className="text-stone-500 font-medium">Assessed Academic Stress Level (1-10)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Cognitive distortions / Triggers diagnosis */}
        <div className="bg-white rounded-2xl p-6 border border-stone-100 shadow-xs lg:col-span-4 space-y-6">
          <div>
            <h3 className="font-semibold text-stone-800 text-sm">Cognitive Trap Diagnostics</h3>
            <p className="text-xs text-stone-500">Unconscious thinking traps triggered during studies.</p>
          </div>

          <div className="space-y-4">
            {popularDistortions.length > 0 ? (
              <div className="space-y-3.5">
                {popularDistortions.map(([distortion, count]) => {
                  const ratio = Math.round((count / totalEntries) * 100);
                  return (
                    <div key={distortion} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-stone-700 flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-500 shrink-0" /> {distortion}
                        </span>
                        <span className="text-stone-400 font-mono text-[10px]">{ratio}% of days</span>
                      </div>
                      <div className="h-1.5 w-full bg-stone-100 rounded-full overflow-hidden">
                        <div className="h-full bg-stone-900 rounded-full" style={{ width: `${ratio}%` }}></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 text-center space-y-2">
                <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-sm">
                  ✓
                </div>
                <div>
                  <h4 className="text-xs font-bold text-emerald-800">Clear Psychological Path</h4>
                  <p className="text-[10px] text-emerald-600 leading-relaxed">No major cognitive illusions locked in. Keep studying with healthy awareness!</p>
                </div>
              </div>
            )}

            {/* Extracted Stress Triggers list */}
            <div className="pt-4 border-t border-stone-100">
              <span className="block text-[10px] text-stone-500 font-bold uppercase tracking-wider mb-2.5">Recurrent stress triggers</span>
              {popularTriggers.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {popularTriggers.map(([trig, count]) => (
                    <span key={trig} className="text-[10px] font-medium text-amber-800 bg-amber-50 border border-amber-200/50 px-2.5 py-1 rounded-md">
                      ⚠️ {trig} ({count}x)
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-stone-500 italic">No recurring study block triggers detected yet.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Recommended study and lifestyle optimization based on telemetry */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 border border-stone-800">
        <h3 className="font-semibold text-stone-100 text-sm mb-1">Empathetic Performance Optimization</h3>
        <p className="text-xs text-stone-400 mb-4">Recommended behavioral adjustments based on recent high-stakes exam logs.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
          <div className="p-4 bg-stone-800 rounded-xl space-y-1.5 border border-stone-800">
            <div className="flex items-center gap-1.5 text-amber-400 font-semibold text-xs uppercase tracking-wide">
              <Clock className="w-3.5 h-3.5" /> Study-Cap suggestions
            </div>
            <p className="text-stone-300 leading-relaxed">
              {Number(averageHours) > 9 
                ? "Your logged study average exceeds 9h. Stagger study sessions into 50-minute blocks with 10-minute somatic breathers to protect study quality from retention decay."
                : "Your study hours are balanced. Keep studying under distraction-free, quiet environments, focusing purely on practice mock solutions."
              }
            </p>
          </div>

          <div className="p-4 bg-stone-800 rounded-xl space-y-1.5 border border-stone-800">
            <div className="flex items-center gap-1.5 text-rose-300 font-semibold text-xs uppercase tracking-wide">
              <AlertTriangle className="w-3.5 h-3.5" /> stress boundaries
            </div>
            <p className="text-stone-300 leading-relaxed">
              {Number(averageStress) >= 6 
                ? "Stress levels are moderate-to-severe. Dedicate 5 complete minutes to Navy SEAL box breathing at sunset to silence cumulative study adrenal load."
                : "Stress indicators are healthy. Continue daily journal venting to maintain high cognitive clarity throughout your preparation milestones."
              }
            </p>
          </div>

          <div className="p-4 bg-stone-800 rounded-xl space-y-1.5 border border-stone-800">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-xs uppercase tracking-wide">
              <Award className="w-3.5 h-3.5" /> peak target state
            </div>
            <p className="text-stone-300 leading-relaxed">
              Focus on positive mindset reframings regarding JEE/UPSC/NEET exams. Consider mocks as informational feedback devices, not personal declarations of self-worth.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
