import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, JournalEntry } from '../types';
import { Send, Heart, User, Sparkles, MessageCircle, RefreshCw, AlertCircle } from 'lucide-react';

interface CompanionSectionProps {
  journalEntries: JournalEntry[];
}

const STARTER_PROMPTS = [
  "I am feeling so stuck and behind on my syllabus. How do I cope?",
  "My mock test scores are dropping. I feel like giving up.",
  "How do I deal with my parents' high pressure and expectations?",
  "I can't fall asleep because my mind runs with exam math.",
  "I have 3 days left for JEE. I'm having a silent panic attack."
];

export default function CompanionSection({ journalEntries }: CompanionSectionProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: "Hello, friend. I'm Ananya, your digital wellness companion. Preparing for high-stakes achievements is a massive emotional hurdle, and it's completely okay to feel overloaded, scared, or exhausted. I'm here to listen, validate, and help you find peace. What's weighing on your mind today?",
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || loading) return;

    setErrorMsg("");
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toISOString()
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText("");
    setLoading(true);

    try {
      // Create context out of past up to 3 journal entries
      const journalContext = journalEntries.slice(0, 3).map(entry => ({
        date: entry.date,
        mood: entry.mood,
        academicTarget: entry.academicTarget,
        entryText: entry.entryText,
        analysis: entry.analysis
      }));

      // Build previous message history for AI format (excluding welcome card if desired)
      const chatHistory = messages
        .filter(m => m.id !== 'welcome')
        .map(m => ({
          sender: m.sender,
          text: m.text
        }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: chatHistory,
          journalContext: journalContext
        })
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || "Failed to talk to Ananya.");
      }

      const data = await response.json();
      
      const aiResponse: ChatMessage = {
        id: crypto.randomUUID(),
        sender: 'ai',
        text: data.response || "I hear you, and I am right here with you. Let's take a deep breath together.",
        timestamp: new Date().toISOString()
      };

      setMessages((prev) => [...prev, aiResponse]);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Unable to reach Ananya. Please double-check your API configurations.");
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputText);
  };

  const clearChatHistory = () => {
    setMessages([
      {
        id: 'welcome',
        sender: 'ai',
        text: "I've cleared our chat slate, but I'm still right here. Vent anytime you need a breather.",
        timestamp: new Date().toISOString()
      }
    ]);
    setErrorMsg("");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8" id="companion-section-root">
      {/* Vent starter prompts sidebar */}
      <div className="lg:col-span-1 space-y-4" id="companion-sidebar">
        <div className="bg-white rounded-2xl p-5 border border-stone-100 shadow-xs">
          <div className="flex items-center gap-2 text-stone-800 font-semibold text-sm mb-3">
            <MessageCircle className="w-4 h-4 text-amber-500" />
            <span>Struggling? Quick Vent Topics</span>
          </div>
          <p className="text-xs text-stone-500 mb-4 leading-relaxed">
            Click any prompt below to immediately open up to Ananya about common test stress triggers:
          </p>
          <div className="space-y-2">
            {STARTER_PROMPTS.map((prompt, idx) => (
              <button
                key={idx}
                id={`companion-starter-prompt-${idx}`}
                onClick={() => handleSendMessage(prompt)}
                disabled={loading}
                className="w-full text-left text-xs bg-stone-50 hover:bg-stone-100/80 active:bg-stone-100 border border-stone-200/60 rounded-xl p-3 text-stone-600 transition-all leading-snug cursor-pointer disabled:opacity-50"
              >
                "{prompt}"
              </button>
            ))}
          </div>

          <div className="mt-5 pt-4 border-t border-stone-100 flex items-center justify-between">
            <span className="text-[10px] text-stone-400 font-mono">Session Live</span>
            <button
              id="reset-chat-history-btn"
              onClick={clearChatHistory}
              className="text-[10px] flex items-center gap-1 text-stone-500 hover:text-stone-800 transition-colors"
            >
              <RefreshCw className="w-2.5 h-2.5" /> Reset Chat
            </button>
          </div>
        </div>
      </div>

      {/* Main chat window */}
      <div className="lg:col-span-3 flex flex-col h-[520px] bg-white rounded-2xl border border-stone-100 shadow-xs overflow-hidden" id="companion-chat-window">
        {/* Chat Header */}
        <div className="bg-stone-900 px-6 py-4 flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-400 to-rose-400 flex items-center justify-center shadow-inner relative">
              <span className="text-lg font-bold text-stone-900">A</span>
              <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border border-stone-900 rounded-full"></div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-semibold text-stone-100 text-sm">Ananya</h3>
                <span className="text-[9px] font-bold bg-amber-500/10 text-amber-300 font-sans px-1.5 py-0.5 rounded-sm border border-amber-500/20 uppercase tracking-wider">Empathetic Companion</span>
              </div>
              <p className="text-[10px] text-stone-400 flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 text-amber-400" /> Grounded in your recent journal insights
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 bg-stone-800/80 px-2.5 py-1 rounded-full border border-stone-700/55">
            <Heart className="w-3 h-3 text-rose-400 fill-rose-400" />
            <span className="text-[10px] text-stone-300 font-medium">Safe Space</span>
          </div>
        </div>

        {/* Chat Messages Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-stone-50/50">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[85%] ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
              >
                {/* Avatar Icon */}
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border ${
                  isUser 
                    ? 'bg-amber-500 text-stone-900 border-amber-600' 
                    : 'bg-stone-900 text-amber-200 border-stone-800'
                }`}>
                  {isUser ? <User className="w-4 h-4" /> : <Heart className="w-4 h-4 fill-amber-200/10" />}
                </div>

                {/* Bubble */}
                <div className="space-y-1">
                  <div className={`rounded-2xl px-4 py-3 text-xs leading-relaxed transition-all shadow-2xs ${
                    isUser 
                      ? 'bg-stone-900 text-amber-50 rounded-tr-none' 
                      : 'bg-white text-stone-800 border border-stone-200/80 rounded-tl-none font-sans font-medium'
                  }`}>
                    {/* Preserve line breaks for clean list spacing from AI response */}
                    {msg.text.split('\n').map((line, lIdx) => (
                      <p key={lIdx} className={lIdx > 0 ? 'mt-1' : ''}>{line}</p>
                    ))}
                  </div>
                  {/* Timestamp */}
                  <span className={`text-[9px] text-stone-400 block px-1 ${isUser ? 'text-right' : 'text-left'}`}>
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            );
          })}

          {loading && (
            <div className="flex gap-3 max-w-[80%] mr-auto items-center animate-pulse">
              <div className="w-8 h-8 rounded-full bg-stone-300 flex items-center justify-center shrink-0">
                <Heart className="w-4 h-4 text-stone-500" />
              </div>
              <div className="bg-white border border-stone-200/60 rounded-2xl rounded-tl-none px-4 py-3 flex items-center gap-2">
                <span className="text-xs text-stone-500">Ananya is reflecting...</span>
                <span className="flex gap-1">
                  <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-bounce delay-100"></span>
                  <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-bounce delay-200"></span>
                  <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-bounce delay-300"></span>
                </span>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="bg-rose-50 border border-rose-100 rounded-xl p-3 text-xs text-rose-600 flex items-start gap-2 max-w-md mx-auto">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold">Counselor Connection Offline</p>
                <p className="text-[11px] mt-0.5">{errorMsg}</p>
              </div>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Action input bar */}
        <form onSubmit={handleFormSubmit} className="p-4 border-t border-stone-200/60 bg-white flex items-center gap-3">
          <label htmlFor="companion-chat-input" className="sr-only">Message Ananya</label>
          <input
            id="companion-chat-input"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={loading}
            placeholder="Tell Ananya what is currently worrying you..."
            className="flex-1 bg-stone-50 text-xs text-stone-800 placeholder-stone-400 border border-stone-200 rounded-xl px-4 py-3 focus:outline-hidden focus:ring-1 focus:ring-amber-500/20 focus:bg-white focus:border-amber-500 transition-all font-medium"
          />
          <button
            id="send-chat-btn"
            type="submit"
            aria-label="Send message to Ananya"
            disabled={!inputText.trim() || loading}
            className="p-3 bg-stone-950 hover:bg-stone-800 disabled:bg-stone-100 disabled:text-stone-300 text-amber-50 rounded-xl transition-all cursor-pointer shadow-xs shrink-0 flex items-center justify-center"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
