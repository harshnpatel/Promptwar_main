import React, { useState } from 'react';
import { JournalEntry, MoodType, JournalAnalysis } from '../types';
import { BookOpen, Sparkles, Smile, Clock, Target, ChevronRight, AlertCircle, Heart, CheckCircle2 } from 'lucide-react';

interface JournalSectionProps {
  entries: JournalEntry[];
  onAddEntry: (entry: Omit<JournalEntry, 'id' | 'date' | 'analysis'> & { id?: string; date?: string; analysis?: JournalAnalysis }) => Promise<void>;
}

const MOODS: { type: MoodType; emoji: string; color: string; bgColor: string }[] = [
  { type: 'Anxious', emoji: '😟', color: 'text-amber-600', bgColor: 'bg-amber-50 border-amber-200' },
  { type: 'Overwhelmed', emoji: '🤯', color: 'text-rose-600', bgColor: 'bg-rose-50 border-rose-200' },
  { type: 'Exhausted', emoji: '🥱', color: 'text-slate-600', bgColor: 'bg-slate-100 border-slate-300' },
  { type: 'Stressed', emoji: '🥵', color: 'text-red-600', bgColor: 'bg-red-50 border-red-200' },
  { type: 'Calm', emoji: '😌', color: 'text-emerald-600', bgColor: 'bg-emerald-50 border-emerald-200' },
  { type: 'Optimistic', emoji: '✨', color: 'text-teal-600', bgColor: 'bg-teal-50 border-teal-200' },
  { type: 'Motivated', emoji: '💪', color: 'text-indigo-600', bgColor: 'bg-indigo-50 border-indigo-200' },
];

const EXAM_OPTIONS = [
  "JEE Prep",
  "NEET Prep",
  "UPSC CSE",
  "CAT Prep",
  "GATE Prep",
  "CUET Prep",
  "CBSE / State Boards",
  "School Term Exams",
  "Other Competitive Exam"
];

export default function JournalSection({ entries, onAddEntry }: JournalSectionProps) {
  const [entryText, setEntryText] = useState("");
  const [selectedMood, setSelectedMood] = useState<MoodType>('Stressed');
  const [academicTarget, setAcademicTarget] = useState("JEE Prep");
  const [hoursStudied, setHoursStudied] = useState<number>(6);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [activeEntry, setActiveEntry] = useState<JournalEntry | null>(entries[0] || null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!entryText.trim()) {
      setErrorMsg("Please write down how your day went. Even a short sentence helps!");
      return;
    }
    setErrorMsg("");
    setLoading(true);

    try {
      const response = await fetch('/api/analyze-journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          entryText,
          mood: selectedMood,
          academicTarget,
          hoursStudied,
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || "Failed to analyze journal.");
      }

      const analysis: JournalAnalysis = await response.json();

      // Assemble new entry
      const newEntry: JournalEntry = {
        id: crypto.randomUUID(),
        date: new Date().toISOString(),
        mood: selectedMood,
        academicTarget,
        hoursStudied,
        entryText,
        analysis,
      };

      await onAddEntry(newEntry);
      
      // Clear input form
      setEntryText("");
      setActiveEntry(newEntry);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "An error occurred during AI analysis. Please verify your Gemini API Key.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="journal-section-root">
      {/* Journal Entry Creation Module */}
      <div className="lg:col-span-7 space-y-6" id="journal-input-card">
        <div className="bg-white rounded-2xl p-6 shadow-xs border border-stone-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 bg-amber-50 rounded-lg text-amber-700">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-semibold text-lg text-stone-800">Daily Reflection Mirror</h2>
              <p className="text-xs text-stone-500">Log your day to let AI unlock your emotions, triggers, and calming tips.</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Exam & Study log context */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="academic-target" className="block text-xs font-semibold text-stone-700 mb-1.5 flex items-center gap-1">
                  <Target className="w-3.5 h-3.5 text-stone-500" /> Academic Target Milestone
                </label>
                <select
                  id="academic-target"
                  value={academicTarget}
                  onChange={(e) => setAcademicTarget(e.target.value)}
                  className="w-full text-sm bg-stone-50 border border-stone-200 rounded-lg px-3 py-2.5 text-stone-700 focus:outline-hidden focus:ring-1 focus:ring-amber-500/30 focus:border-amber-500 transition-all font-medium"
                >
                  {EXAM_OPTIONS.map((exam) => (
                    <option key={exam} value={exam}>{exam}</option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="hours-studied" className="block text-xs font-semibold text-stone-700 mb-1.5 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-stone-500" /> Study Hours Logged Today
                </label>
                <input
                  id="hours-studied"
                  type="number"
                  min="0"
                  max="24"
                  value={hoursStudied}
                  onChange={(e) => setHoursStudied(Number(e.target.value))}
                  className="w-full text-sm bg-stone-50 border border-stone-200 rounded-lg px-3 py-2 text-stone-700 focus:outline-hidden focus:ring-1 focus:ring-amber-500/30 focus:border-amber-500 transition-all font-medium"
                />
              </div>
            </div>

            {/* Mood picker */}
            <div>
              <span id="mood-picker-label" className="block text-xs font-semibold text-stone-700 mb-2 flex items-center gap-1">
                <Smile className="w-3.5 h-3.5 text-stone-500" /> Overall Prevailing Energy right now
              </span>
              <div className="flex flex-wrap gap-2" role="group" aria-labelledby="mood-picker-label">
                {MOODS.map((m) => (
                  <button
                    key={m.type}
                    id={`mood-picker-${m.type.toLowerCase()}`}
                    type="button"
                    aria-pressed={selectedMood === m.type}
                    onClick={() => setSelectedMood(m.type)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                      selectedMood === m.type
                        ? `${m.bgColor} shadow-xs ring-1 ring-stone-900/5 scale-102`
                        : "bg-white border-stone-200 text-stone-600 hover:bg-stone-50"
                    }`}
                  >
                    <span role="img" aria-label={m.type}>{m.emoji}</span>
                    <span className={m.color}>{m.type}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Open-ended Journal */}
            <div>
              <label htmlFor="journal-reflection-text" className="block text-xs font-semibold text-stone-700 mb-1.5">
                Share your unfiltered thoughts (vent about test fatigue, syllabus blocks, self-doubt, family, or sleep)
              </label>
              <textarea
                id="journal-reflection-text"
                value={entryText}
                onChange={(e) => setEntryText(e.target.value)}
                placeholder="I felt very stuck with physics revision today... Mock papers are getting harder. I feel like My efforts aren't translating into scores and I don't want to let my family down. Scared of exam day..."
                rows={5}
                className="w-full text-sm bg-stone-50 border border-stone-200 rounded-lg p-3 text-stone-700 placeholder-stone-400 focus:outline-hidden focus:ring-1 focus:ring-amber-500/30 focus:border-amber-500 transition-all leading-relaxed"
              ></textarea>
            </div>

            {/* Errors display */}
            {errorMsg && (
              <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-xs text-rose-600 flex items-start gap-2" id="journal-error-card">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Submit section */}
            <div className="flex justify-end pt-2">
              <button
                id="submit-journal-reflection-btn"
                type="submit"
                disabled={loading}
                className="flex items-center gap-2 px-5 py-2.5 bg-stone-900 text-amber-50 hover:bg-stone-800 disabled:bg-stone-400 rounded-xl text-xs font-medium transition-all shadow-xs cursor-pointer hover:shadow-md"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-amber-100 border-t-white rounded-full animate-spin"></div>
                    Evaluating emotional coordinates...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    Send entry to AI Psychologist
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Previous logs listing */}
        <div className="bg-stone-50 rounded-2xl p-5 border border-stone-200/50">
          <h3 className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-3">Academic Journal history</h3>
          {entries.length === 0 ? (
            <div className="text-center py-6 bg-white rounded-xl border border-dashed border-stone-200 p-4">
              <p className="text-xs text-stone-400">Your journal cabinet is empty. Create your first reflection to seed stress tracking.</p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[280px] overflow-y-auto pr-1">
              {entries.map((entry) => {
                const moodObj = MOODS.find(m => m.type === entry.mood);
                const isActive = activeEntry?.id === entry.id;
                return (
                  <button
                    key={entry.id}
                    id={`journal-history-item-${entry.id}`}
                    aria-current={isActive ? 'true' : 'false'}
                    onClick={() => setActiveEntry(entry)}
                    className={`w-full text-left bg-white p-3 rounded-xl border transition-all hover:border-stone-400 flex items-center justify-between gap-3 ${
                      isActive ? 'border-amber-500 ring-1 ring-amber-500/20 shadow-xs' : 'border-stone-200/80'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                        <span className="text-xs font-semibold text-stone-700">{entry.academicTarget}</span>
                        <span className="text-[10px] text-stone-400">• {new Date(entry.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      <p className="text-xs text-stone-500 truncate max-w-[340px] italic">"{entry.entryText}"</p>
                    </div>
                    
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-xs bg-stone-50 px-2 py-0.5 rounded-full border border-stone-100">
                        {entry.hoursStudied}h
                      </span>
                      <span className="text-base select-none">
                        {moodObj?.emoji || "📝"}
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* AI Psychologist Deep Insights Console */}
      <div className="lg:col-span-5" id="journal-analysis-display">
        {activeEntry ? (
          <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 shadow-md border border-stone-800 space-y-5 h-full flex flex-col justify-between">
            <div>
              {/* Header */}
              <div className="flex items-start justify-between gap-4 mb-4 border-b border-stone-800 pb-3">
                <div>
                  <div className="flex items-center gap-2 text-stone-400 text-[10px] uppercase font-bold tracking-wider">
                    <Sparkles className="w-3 h-3 text-amber-400" /> Counseling Report
                  </div>
                  <h3 className="font-semibold text-base text-stone-100">Analysis & Compassionate Assessment</h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-stone-500 block">Logged State</span>
                  <span className="text-sm font-semibold text-amber-300">
                    {MOODS.find(m => m.type === activeEntry.mood)?.emoji} {activeEntry.mood}
                  </span>
                </div>
              </div>

              {activeEntry.analysis ? (
                <div className="space-y-4 text-xs leading-relaxed">
                  {/* Stress Thermometer */}
                  <div>
                    <div className="flex items-center justify-between text-[11px] mb-1.5 font-medium text-stone-400">
                      <span>Assessed Stress Load</span>
                      <span className={`font-bold ${activeEntry.analysis.stressLevel >= 7 ? 'text-rose-400' : activeEntry.analysis.stressLevel >= 4 ? 'text-amber-400' : 'text-emerald-400'}`}>
                        {activeEntry.analysis.stressLevel} / 10
                      </span>
                    </div>
                    <div className="h-2 w-full bg-stone-800 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${
                          activeEntry.analysis.stressLevel >= 7 
                            ? 'bg-rose-500' 
                            : activeEntry.analysis.stressLevel >= 4 
                              ? 'bg-amber-500' 
                              : 'bg-emerald-500'
                        }`}
                        style={{ width: `${activeEntry.analysis.stressLevel * 10}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Primary Emotions */}
                  <div>
                    <span className="block text-[11px] text-stone-400 font-medium mb-1.5">Primary Emotional Nuances</span>
                    <div className="flex flex-wrap gap-1.5">
                      {activeEntry.analysis.primaryEmotions.map((emotion) => (
                        <span key={emotion} className="bg-stone-800 text-stone-300 px-2 py-0.5 rounded-md text-[10px] border border-stone-700/60 font-medium">
                          {emotion}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Stress Triggers */}
                  <div>
                    <span className="block text-[11px] text-stone-400 font-medium mb-1.5">Hidden Triggers Excavated</span>
                    {activeEntry.analysis.hiddenTriggers.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5">
                        {activeEntry.analysis.hiddenTriggers.map((trig) => (
                          <span key={trig} className="bg-stone-800/80 text-amber-200/90 px-2.5 py-0.5 rounded-full text-[10px] border border-amber-950/40">
                            🚨 {trig}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-stone-500 italic text-[10px]">No deep stress triggers noted in text analysis.</p>
                    )}
                  </div>

                  {/* Cognitive Distortions */}
                  <div>
                    <span className="block text-[11px] text-stone-400 font-medium mb-1.5">Unconscious Thinking Traps (Distortions)</span>
                    {activeEntry.analysis.cognitiveDistortions && activeEntry.analysis.cognitiveDistortions.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5">
                        {activeEntry.analysis.cognitiveDistortions.map((distortion) => (
                          <span key={distortion} className="bg-rose-950/40 text-rose-300 px-2.5 py-0.5 rounded-full text-[10px] border border-rose-900/40 flex items-center gap-1.0">
                            ⚠️ {distortion}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <div className="text-emerald-400 text-[10px] bg-emerald-950/20 px-2 py-1 rounded-md border border-emerald-900/30 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5" /> No major self-limiting distortions identified. Healthy framing!
                      </div>
                    )}
                  </div>

                  {/* Counselor Letter */}
                  <div className="bg-stone-800/60 border border-stone-800 rounded-xl p-3.5 space-y-2 mt-2">
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-300">
                      <Heart className="w-3.5 h-3.5 fill-amber-300" /> Counselor's Comfort Note
                    </div>
                    <p className="text-stone-300 leading-relaxed text-xs italic font-serif">
                      "{activeEntry.analysis.personalizedAdvice}"
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-10 space-y-3">
                  <div className="w-8 h-8 rounded-full border border-stone-800 border-t-white animate-spin mx-auto"></div>
                  <p className="text-xs text-stone-400">Loading psychological parameters...</p>
                </div>
              )}
            </div>

            {/* Call to Wellness Activity suggestions */}
            {activeEntry.analysis && (
              <div className="pt-4 border-t border-stone-800 flex items-center justify-between gap-3 flex-wrap bg-stone-950/30 p-2.5 rounded-xl border border-stone-800/40">
                <div className="min-w-0">
                  <span className="text-[9px] text-stone-500 uppercase tracking-widest block font-bold">Recommended Coping Activity</span>
                  <span className="text-xs text-stone-200 font-semibold truncate block">{activeEntry.analysis.recommendedActivity}</span>
                </div>
                <div className="text-[10px] bg-amber-400 text-stone-900 font-bold px-2 py-1 rounded-md">
                  Active Suggestion
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-stone-900 text-stone-300 rounded-2xl p-8 shadow-md border border-stone-800 text-center h-full flex flex-col justify-center items-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-stone-800 flex items-center justify-center text-stone-500 text-xl border border-stone-700">
              📌
            </div>
            <div>
              <h3 className="font-semibold text-stone-100 text-sm">Select or Create a Reflective entry</h3>
              <p className="text-xs text-stone-500 max-w-[260px] mx-auto mt-1">
                Your AI-powered stress summary, cognitive trap diagnostics, and soothing counselor advice will activate here.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
